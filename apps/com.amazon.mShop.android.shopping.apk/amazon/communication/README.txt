BE AWARE. Any java file added to this directory or any subdirectory will be included in the Amplify SDK
unless annotated with @hide. Once added, non-backwards-compatible API changes that aren't hidden will
be considered build breaks!

See https://dp.amazon.com/display/SDK/Project+B+SDK+(amplify)
